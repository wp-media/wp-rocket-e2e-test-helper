<?php
/**
 * Plugin Name: WP Mobile Enforce
 * Description: Sets the wp_is_mobile to true
 * Author:      WP Rocket Team
 * Author URI:  http://wp-rocket.me/
 * License:     GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Copyright SAS WP MEDIA 2024
 */

add_filter('wp_is_mobile', '__return_true');
