<?php
/**
 * Plugin Name: WP Rocket | Disable PH SaaS Visit 
 * Description: Removes WP Rocket Performance Hints SaaS visit query arg
 * Author:      WP Rocket Dev Team
 * Author URI:  http://wp-rocket.me/
 * License:     GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Copyright SAS WP MEDIA 2024
 */

// Remove SaaS visit query arg.
add_filter( 'rocket_saas_api_queued_url', function( $url ) {
	return remove_query_arg( 'wpr_imagedimensions', $url );
}, 11 );