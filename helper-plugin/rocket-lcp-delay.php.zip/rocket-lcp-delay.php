<?php
/**
 * Plugin Name: WP Rocket LCP Delay
 * Description: Sets the rocket_lcp_delay to to a higher delay value.
 * Author:      WP Rocket Team
 * Author URI:  http://wp-rocket.me/
 * License:     GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Copyright SAS WP MEDIA 2024
 */

 add_filter( 'rocket_lcp_delay', function() {
	return 5000;
} );
