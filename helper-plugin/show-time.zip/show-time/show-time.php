<?php
/**
 * Plugin Name: WP Show Current Time
 * Description: Show current time in admin bar
 * Author:      BackWpUp Team
 * Author URI:  https://backwpup.com/
 * License:     GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Copyright SAS WP MEDIA 2025
 */

add_action( 'admin_bar_menu', function( $admin_bar ) {
    if ( ! is_admin_bar_showing() ) {
        return;
    } 

    // Get current time (using WordPress timezone settings).
    $current_time = current_time( 'H:i:s' );
    $current_date = current_time( 'M j, Y' );

    $admin_bar->add_node( [
        'id'    => 'current_time_display',
        'title' => $current_time . ' (' . $current_date . ')',
        'meta'  => [
            'title' => 'Time at page loading, based on WordPress timezone settings',
        ],
    ] );
}, 100 );
